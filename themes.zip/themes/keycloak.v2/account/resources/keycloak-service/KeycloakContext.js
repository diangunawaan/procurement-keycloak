import * as React from "../../../common/keycloak/web_modules/react.js";
export const KeycloakContext = React.createContext(undefined);
//# sourceMappingURL=KeycloakContext.js.map